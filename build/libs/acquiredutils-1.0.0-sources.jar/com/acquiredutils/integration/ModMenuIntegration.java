package com.acquiredutils.integration;

import com.acquiredutils.config.ConfigManager;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import dev.isxander.yacl3.api.*;
import dev.isxander.yacl3.api.controller.*;
import net.minecraft.class_2561;

public class ModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> YetAnotherConfigLib.createBuilder()
            .title(class_2561.method_43470("AcquiredUtils"))
            .category(ConfigCategory.createBuilder().name(class_2561.method_43470("Notifications"))
                .option(Option.<Integer>createBuilder().name(class_2561.method_43470("X Position"))
                    .description(OptionDescription.of(class_2561.method_43470("Horizontal position. -1 for default.")))
                    .binding(-1, () -> ConfigManager.get().notificationX, v -> ConfigManager.get().notificationX = v)
                    .controller(opt -> IntegerSliderControllerBuilder.create(opt).range(-1, 1920).step(1)).build())
                .option(Option.<Integer>createBuilder().name(class_2561.method_43470("Y Position"))
                    .description(OptionDescription.of(class_2561.method_43470("Vertical position. -1 for default.")))
                    .binding(-1, () -> ConfigManager.get().notificationY, v -> ConfigManager.get().notificationY = v)
                    .controller(opt -> IntegerSliderControllerBuilder.create(opt).range(-1, 1080).step(1)).build())
                .build())
            .category(ConfigCategory.createBuilder().name(class_2561.method_43470("Rarity Filter"))
                .option(Option.<Boolean>createBuilder().name(class_2561.method_43470("Show Common")).binding(true, () -> ConfigManager.get().showCommon, v -> ConfigManager.get().showCommon = v).controller(BooleanControllerBuilder::create).build())
                .option(Option.<Boolean>createBuilder().name(class_2561.method_43470("Show Uncommon")).binding(true, () -> ConfigManager.get().showUncommon, v -> ConfigManager.get().showUncommon = v).controller(BooleanControllerBuilder::create).build())
                .option(Option.<Boolean>createBuilder().name(class_2561.method_43470("Show Rare")).binding(true, () -> ConfigManager.get().showRare, v -> ConfigManager.get().showRare = v).controller(BooleanControllerBuilder::create).build())
                .option(Option.<Boolean>createBuilder().name(class_2561.method_43470("Show Epic")).binding(true, () -> ConfigManager.get().showEpic, v -> ConfigManager.get().showEpic = v).controller(BooleanControllerBuilder::create).build())
                .option(Option.<Boolean>createBuilder().name(class_2561.method_43470("Show Legendary")).binding(true, () -> ConfigManager.get().showLegendary, v -> ConfigManager.get().showLegendary = v).controller(BooleanControllerBuilder::create).build())
                .option(Option.<Boolean>createBuilder().name(class_2561.method_43470("Show Mythic")).binding(true, () -> ConfigManager.get().showMythic, v -> ConfigManager.get().showMythic = v).controller(BooleanControllerBuilder::create).build())
                .build())
            .save(ConfigManager::save).build().generateScreen(parent);
    }
}