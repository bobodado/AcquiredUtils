package com.acquiredutils.mixin;

import com.acquiredutils.rarity.RarityDetector;
import com.acquiredutils.rarity.RarityType;
import net.minecraft.class_1735;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public class HandledScreenMixin {
    private static final int S = 3;
    @Inject(method = "renderSlot", at = @At("TAIL"))
    private void onSlot(class_332 g, class_1735 slot, int x, int y, CallbackInfo ci) {
        if (slot.method_7681()) {
            RarityType r = RarityDetector.detectRarity(slot.method_7677());
            if (r != RarityType.COMMON) renderIndicator(g, slot, r);
        }
    }
    private void renderIndicator(class_332 g, class_1735 slot, RarityType r) {
        int x = slot.field_7873, y = slot.field_7872 + 16 - S * 3;
        g.method_51448().pushMatrix();
        int c = 0xFF000000 | r.getColor();
        for (int row = 0; row < 3; row++)
            for (int col = 0; col < 3; col++)
                g.method_25294(x + col * S, y + row * S, x + col * S + S, y + row * S + S, c);
        g.method_51448().popMatrix();
    }
}