package com.acquiredutils.mixin;

import com.acquiredutils.notification.AcquiredUtilsNotifier;
import com.acquiredutils.rarity.RarityDetector;
import com.acquiredutils.rarity.RarityType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.*;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_746;

@Mixin(class_746.class)
public class ClientPlayerEntityMixin {
    @Unique private Map<class_1792, Map<RarityType, Integer>> prevTotals = new HashMap<>();
    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        class_746 player = (class_746)(Object)this;
        class_1661 inv = player.method_31548();
        Map<class_1792, Map<RarityType, Integer>> cur = new HashMap<>();
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 s = inv.method_5438(i);
            if (!s.method_7960()) {
                RarityType r = RarityDetector.detectRarity(s);
                cur.computeIfAbsent(s.method_7909(), k -> new HashMap<>()).merge(r, s.method_7947(), Integer::sum);
            }
        }
        if (!prevTotals.isEmpty()) {
            for (var e : cur.entrySet()) {
                class_1792 item = e.getKey();
                var curR = e.getValue();
                var prevR = prevTotals.getOrDefault(item, Collections.emptyMap());
                for (var re : curR.entrySet()) {
                    RarityType r = re.getKey();
                    int cc = re.getValue(), pc = prevR.getOrDefault(r, 0);
                    if (cc > pc) {
                        class_1799 gained = new class_1799(item, cc - pc);
                        for (int i = 0; i < inv.method_5439(); i++) {
                            class_1799 is = inv.method_5438(i);
                            if (!is.method_7960() && is.method_7909() == item && RarityDetector.detectRarity(is) == r) {
                                gained = is.method_7972(); gained.method_7939(cc - pc); break;
                            }
                        }
                        AcquiredUtilsNotifier.onItemAcquired(gained);
                    }
                }
            }
        }
        prevTotals = cur;
        AcquiredUtilsNotifier.tick();
    }
}