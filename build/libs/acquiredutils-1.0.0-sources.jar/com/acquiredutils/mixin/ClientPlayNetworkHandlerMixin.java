package com.acquiredutils.mixin;

import com.acquiredutils.notification.AcquiredUtilsNotifier;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_2775;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPlayNetworkHandlerMixin {
    @Inject(method = "handleTakeItemEntity", at = @At("HEAD"))
    private void onPickup(class_2775 p, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;
        class_1297 item = mc.field_1687.method_8469(p.method_11915());
        class_1297 player = mc.field_1687.method_8469(p.method_11912());
        if (item instanceof class_1542 ie && player == mc.field_1724) {
            class_1799 s = ie.method_6983().method_7972();
            if (p.method_11913() > 0) s.method_7939(Math.min(p.method_11913(), s.method_7947()));
            AcquiredUtilsNotifier.onItemAcquired(s);
        }
    }
}