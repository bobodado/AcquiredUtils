package com.acquiredutils.notification;

import com.acquiredutils.config.AcquiredUtilsConfig;
import com.acquiredutils.config.ConfigManager;
import com.acquiredutils.hud.HudEditorScreen;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class NotificationRenderer {
    private static final int W = 160, H = 32, BORDER = 3;
    public static void init() {}
    public static void render(class_332 g) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1755 != null && !(mc.field_1755 instanceof HudEditorScreen)) return;
        AcquiredUtilsConfig cfg = ConfigManager.get();
        int sw = mc.method_22683().method_4486();
        int sh = mc.method_22683().method_4502();
        List<Notification> active = AcquiredUtilsNotifier.getNotifications();
        if (active.isEmpty() && !(mc.field_1755 instanceof HudEditorScreen)) return;
        int x = cfg.notificationX < 0 ? sw - W - 10 : cfg.notificationX;
        int y = cfg.notificationY < 0 ? sh / 2 - (active.size() * (H + 4)) / 2 : cfg.notificationY;
        for (Notification n : active) { renderOne(g, n, x, y); y += H + 4; }
    }
    private static void renderOne(class_332 g, Notification n, int x, int y) {
        float a = n.getFadeAlpha();
        if (a <= 0.01f) return;
        int abg = (int)(a * 200);
        int afg = (int)(a * 255);
        int bg = (abg << 24) | 0x141414;
        int border = (afg << 24) | (n.getRarity().getColor() & 0xFFFFFF);
        int tc = (afg << 24) | 0xFFFFFF;
        g.method_51448().pushMatrix();
        g.method_25294(x, y, x + W, y + H, bg);
        g.method_25294(x, y, x + BORDER, y + H, border);
        g.method_51433(class_310.method_1551().field_1772, n.getDisplayText(), x + BORDER + 8, y + (H - 8) / 2, tc, false);
        g.method_51448().popMatrix();
    }
}