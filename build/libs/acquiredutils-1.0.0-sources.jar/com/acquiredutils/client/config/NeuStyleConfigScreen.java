package com.acquiredutils.client.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;

public class NeuStyleConfigScreen extends class_437 {

    private static final int PANEL_MAX_W = 500;
    private static final int PANEL_MAX_H = 400;
    private static final int SIDEBAR_W = 140;
    private static final int INNER_PADDING = 10;
    private static final int TITLE_BAR_H = 20;
    private static final int CATEGORY_ROW_H = 15;

    private static final int COLOR_DIM_OVERLAY = 0x90101010;
    private static final int COLOR_PANEL_MAIN = 0xFF202026;
    private static final int COLOR_PANEL_LIGHT = 0xFF303036;
    private static final int COLOR_PANEL_DARK = 0xFF101016;
    private static final int COLOR_BORDER_DARK = 0xFF08080E;
    private static final int COLOR_BORDER_SIDEBAR = 0xFF28282E;
    private static final int COLOR_BORDER_CONTENT = 0xFF303036;
    private static final int COLOR_BORDER_FILL = 0x6008080E;
    private static final int COLOR_ACCENT_PURPLE = 0xFFA368EF;
    private static final int COLOR_CATEGORY_SELECTED = 0xFF5DBFBF;
    private static final int COLOR_CATEGORY_UNSELECTED = 0xFFA0A0A0;
    private static final int COLOR_SCROLLBAR_TRACK = 0xFF101010;
    private static final int COLOR_SCROLLBAR_THUMB = 0xFF303030;

    private final List<ConfigCategory> categories = new ArrayList<>();
    private final ScrollableListWidget listWidget = new ScrollableListWidget();

    private ConfigCategory selectedCategory;
    private float categoryScroll = 0f;

    private class_342 searchField;
    private String lastSearch = "";
    private ConfigCategory searchResultsCategory;

    private int panelX, panelY, panelW, panelH;
    private int sidebarInnerLeft, sidebarInnerTop, sidebarInnerRight, sidebarInnerBottom;
    private int contentInnerLeft, contentInnerTop, contentInnerRight, contentInnerBottom;

    private double lastMouseX, lastMouseY;

    public NeuStyleConfigScreen() {
        super(class_2561.method_43470("AcquiredUtils Configuration"));

        Map<String, ConfigCategory> registered = ConfigRegistry.getCategories();
        if (registered.isEmpty()) {
            ConfigCategory demo = ConfigRegistry.getOrCreate("General", "General AcquiredUtils settings");
            demo.add(new com.acquiredutils.client.config.widget.BooleanSettingWidget(
                "Show Overlay", "Toggles the rarity overlay in your inventory", true, val -> {}));
            demo.add(new com.acquiredutils.client.config.widget.SliderSettingWidget(
                "Overlay Scale", "Size of the overlay text", 1.0, 0.5, 2.0, 0.05, val -> {}));
        }
        this.categories.addAll(ConfigRegistry.getCategories().values());
        if (!categories.isEmpty()) {
            selectedCategory = categories.get(0);
        }
    }

    @Override
    protected void method_25426() {
        computeLayout();

        searchField = new class_342(this.field_22793, contentInnerRight - 130, contentInnerTop - 24, 110, 16, class_2561.method_43470("Search"));
        searchField.method_1858(false);
        searchField.method_1880(64);
        searchField.method_1868(0xC0C0C0);
        searchField.method_47404(class_2561.method_43470("Search...").method_27694(style -> style.method_36139(0x606060)));
        method_37063(searchField);

        listWidget.setBounds(contentInnerLeft + 1, contentInnerTop + 1,
            contentInnerRight - contentInnerLeft - 2, contentInnerBottom - contentInnerTop - 2);
        listWidget.setCategory(selectedCategory);
    }

    private void computeLayout() {
        panelW = Math.min(this.field_22789 - 40, PANEL_MAX_W);
        panelH = Math.min(this.field_22790 - 40, PANEL_MAX_H);
        panelX = (this.field_22789 - panelW) / 2;
        panelY = (this.field_22790 - panelH) / 2;

        sidebarInnerLeft = panelX + 4 + INNER_PADDING;
        sidebarInnerRight = panelX + 144 - INNER_PADDING;
        sidebarInnerTop = panelY + 49 + INNER_PADDING;
        sidebarInnerBottom = panelY + panelH - 5 - INNER_PADDING;

        contentInnerLeft = panelX + 149 + INNER_PADDING;
        contentInnerRight = panelX + panelW - 5 - INNER_PADDING;
        contentInnerTop = sidebarInnerTop;
        contentInnerBottom = sidebarInnerBottom;
    }

    @Override
    public void method_25410(int width, int height) {
        super.method_25410(width, height);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        this.lastMouseX = mouseX;
        this.lastMouseY = mouseY;
        graphics.method_25294(0, 0, this.field_22789, this.field_22790, COLOR_DIM_OVERLAY);

        drawFloatingPanel(graphics, panelX, panelY, panelW, panelH);

        drawFloatingPanel(graphics, panelX + 5, panelY + 5, panelW - 10, TITLE_BAR_H);
        graphics.method_25300(this.field_22793, "AcquiredUtils Configuration",
            panelX + panelW / 2, panelY + 11, 0xA0A0A0);

        drawFloatingPanel(graphics, panelX + 4, panelY + 29, SIDEBAR_W, panelH - 34);
        drawInsetBorder(graphics, sidebarInnerLeft, sidebarInnerTop, sidebarInnerRight, sidebarInnerBottom, COLOR_BORDER_SIDEBAR);

        renderSidebar(graphics, mouseX, mouseY);

        graphics.method_25300(this.field_22793, "Categories", panelX + 75, panelY + 40, COLOR_ACCENT_PURPLE);

        drawFloatingPanel(graphics, panelX + 149, panelY + 29, panelW - 154, panelH - 34);
        drawInsetBorder(graphics, contentInnerLeft, contentInnerTop, contentInnerRight, contentInnerBottom, COLOR_BORDER_CONTENT);

        if (activeCategory() != null) {
            graphics.method_65179(this.field_22793, class_2561.method_43470(activeCategory().getDescription()),
                contentInnerLeft + 5, panelY + 40, contentInnerRight - contentInnerLeft - 150, 0xB0B0B0);
        }

        listWidget.setCategory(activeCategory());
        listWidget.render(graphics, this.field_22793, mouseX, mouseY, partialTick);

        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    private ConfigCategory activeCategory() {
        return searchResultsCategory != null ? searchResultsCategory : selectedCategory;
    }

    private void renderSidebar(class_332 graphics, int mouseX, int mouseY) {
        if (categories.isEmpty()) return;

        graphics.method_44379(sidebarInnerLeft, sidebarInnerTop, sidebarInnerRight, sidebarInnerBottom);

        int catY = sidebarInnerTop + 12 - (int) categoryScroll;
        for (ConfigCategory category : categories) {
            boolean selected = (searchResultsCategory == null) && category == selectedCategory;
            int color = selected ? COLOR_CATEGORY_SELECTED : COLOR_CATEGORY_UNSELECTED;

            class_2561 label = class_2561.method_43470(category.getName());
            if (selected) {
                label = label.method_27661().method_27694(style -> style.method_30938(true));
            }
            graphics.method_27534(this.field_22793, label, panelX + 75, catY - 4, color);

            catY += CATEGORY_ROW_H;
        }

        graphics.method_44380();

        int contentHeight = (categories.size() * CATEGORY_ROW_H);
        int viewHeight = sidebarInnerBottom - sidebarInnerTop;
        if (contentHeight > viewHeight) {
            drawScrollbar(graphics, sidebarInnerLeft + 2, sidebarInnerTop + 5, sidebarInnerLeft + 7,
                sidebarInnerBottom - 5, categoryScroll, contentHeight, viewHeight);
        }
    }

    private void drawScrollbar(class_332 graphics, int x1, int y1, int x2, int y2, float scroll, int contentHeight, int viewHeight) {
        graphics.method_25294(x1, y1, x2, y2, COLOR_SCROLLBAR_TRACK);
        int max = Math.max(1, contentHeight - viewHeight);
        float barSize = Math.min(1f, (float) viewHeight / contentHeight);
        int trackH = y2 - y1;
        int thumbH = Math.max(8, Math.round(trackH * barSize));
        int thumbY = y1 + Math.round((trackH - thumbH) * (scroll / max));
        graphics.method_25294(x1 + 1, thumbY, x2 - 1, thumbY + thumbH, COLOR_SCROLLBAR_THUMB);
    }

    private void drawFloatingPanel(class_332 graphics, int x, int y, int w, int h) {
        graphics.method_25294(x, y, x + 1, y + h, COLOR_PANEL_LIGHT);
        graphics.method_25294(x + 1, y, x + w, y + 1, COLOR_PANEL_LIGHT);
        graphics.method_25294(x + w - 1, y + 1, x + w, y + h, COLOR_PANEL_DARK);
        graphics.method_25294(x + 1, y + h - 1, x + w - 1, y + h, COLOR_PANEL_DARK);
        graphics.method_25294(x + 1, y + 1, x + w - 1, y + h - 1, COLOR_PANEL_MAIN);
    }

    private void drawInsetBorder(class_332 graphics, int left, int top, int right, int bottom, int rightBottomColor) {
        graphics.method_25294(left, top, left + 1, bottom, COLOR_BORDER_DARK);
        graphics.method_25294(left + 1, top, right, top + 1, COLOR_BORDER_DARK);
        graphics.method_25294(right - 1, top + 1, right, bottom, rightBottomColor);
        graphics.method_25294(left + 1, bottom - 1, right - 1, bottom, rightBottomColor);
        graphics.method_25294(left + 1, top + 1, right - 1, bottom - 1, COLOR_BORDER_FILL);
    }

    // ---------------------------------------------------------------- input

    private int extractButton(net.minecraft.class_11909 event) {
        try { return (int) event.getClass().getMethod("button").invoke(event); } catch (Exception e) {
            try { return (int) event.getClass().getMethod("getButton").invoke(event); } catch (Exception e2) { return 0; }
        }
    }

    private int extractKeyCode(net.minecraft.class_11908 event) {
        try { return (int) event.getClass().getMethod("keyCode").invoke(event); } catch (Exception e) {
            try { return (int) event.getClass().getMethod("key").invoke(event); } catch (Exception e2) { return 0; }
        }
    }

    @Override
    public boolean method_25402(net.minecraft.class_11909 event, boolean handled) {
        if (super.method_25402(event, handled)) {
            return true;
        }

        double mouseX = this.lastMouseX;
        double mouseY = this.lastMouseY;
        int button = extractButton(event);

        if (button == 0 && mouseX >= sidebarInnerLeft && mouseX <= sidebarInnerRight &&
            mouseY >= sidebarInnerTop && mouseY <= sidebarInnerBottom) {
            int catY = sidebarInnerTop + 12 - (int) categoryScroll;
            for (ConfigCategory category : categories) {
                if (mouseY >= catY - 7 && mouseY <= catY + 7) {
                    selectedCategory = category;
                    searchResultsCategory = null;
                    searchField.method_1852("");
                    return true;
                }
                catY += CATEGORY_ROW_H;
            }
        }

        return listWidget.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(net.minecraft.class_11909 event, double dragX, double dragY) {
        double mouseX = this.lastMouseX;
        double mouseY = this.lastMouseY;
        int button = extractButton(event);
        if (listWidget.mouseDragged(mouseX, mouseY, button, dragX, dragY)) {
            return true;
        }
        return super.method_25403(event, dragX, dragY);
    }

    @Override
    public boolean method_25406(net.minecraft.class_11909 event) {
        double mouseX = this.lastMouseX;
        double mouseY = this.lastMouseY;
        int button = extractButton(event);
        boolean handled = listWidget.mouseReleased(mouseX, mouseY, button);
        return super.method_25406(event) || handled;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (mouseX < sidebarInnerLeft) {
            int contentHeight = categories.size() * CATEGORY_ROW_H;
            int viewHeight = sidebarInnerBottom - sidebarInnerTop;
            int max = Math.max(0, contentHeight - viewHeight);
            categoryScroll = Math.max(0, Math.min(max, categoryScroll - (float) (scrollY * 15)));
            return true;
        }
        return listWidget.mouseScrolled(mouseX, mouseY, scrollY) || super.method_25401(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean method_25400(net.minecraft.class_11905 event) {
        boolean handled = super.method_25400(event);
        runSearchIfChanged();
        return handled;
    }

    @Override
    public boolean method_25404(net.minecraft.class_11908 event) {
        boolean handled = super.method_25404(event);
        runSearchIfChanged();

        if (extractKeyCode(event) == 256) { // GLFW.GLFW_KEY_ESCAPE
            this.method_25419();
            return true;
        }
        return handled;
    }

    private void runSearchIfChanged() {
        if (searchField == null) return;
        String search = searchField.method_1882().trim().toLowerCase();
        if (search.equals(lastSearch)) return;
        lastSearch = search;

        if (search.isEmpty()) {
            searchResultsCategory = null;
            return;
        }

        ConfigCategory results = new ConfigCategory("Search Results", "Matches for \"" + search + "\"");
        for (ConfigCategory category : categories) {
            for (Setting<?> setting : category.getSettings()) {
                String haystack = (setting.getName() + " " + setting.getDescription()).toLowerCase();
                if (haystack.contains(search)) {
                    results.add(setting);
                }
            }
        }
        searchResultsCategory = results;
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}