package com.acquiredutils.client;

import com.acquiredutils.AcquiredUtils;
import com.acquiredutils.config.ConfigManager;
import com.acquiredutils.hud.HudEditorScreen;
import com.acquiredutils.notification.AcquiredUtilsNotifier;
import com.acquiredutils.notification.NotificationRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class AcquiredUtilsClient implements ClientModInitializer {
    public static class_304 HUD_EDITOR_KEY;
    @Override
    public void onInitializeClient() {
        AcquiredUtils.init();
        ConfigManager.load();
        HUD_EDITOR_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.acquiredutils.hud_editor",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_U,
            class_304.class_11900.method_74698(class_2960.method_60655("acquiredutils", "general"))
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (HUD_EDITOR_KEY.method_1436()) {
                if (client.field_1755 == null) client.method_1507(new HudEditorScreen());
            }
        });

        // allow opening from the keybind screen if remapped
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (class_310.method_1551().field_1755 == null && HUD_EDITOR_KEY.method_1434()) {
                class_310.method_1551().method_1507(new HudEditorScreen());
            }
        });
        AcquiredUtilsNotifier.init();
        NotificationRenderer.init();
    }
}