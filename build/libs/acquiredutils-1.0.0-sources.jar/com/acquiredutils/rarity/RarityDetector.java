package com.acquiredutils.rarity;

import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

public class RarityDetector {
    public static RarityType detectRarity(class_1799 stack) {
        if (stack.method_7960()) return RarityType.COMMON;
        RarityType custom = detectCustomRarity(stack);
        if (custom != null) return custom;
        class_1814 vanilla = stack.method_58694(class_9334.field_50073);
        if (vanilla != null) {
            return switch (vanilla) {
                case field_8907 -> RarityType.UNCOMMON;
                case field_8903 -> RarityType.RARE;
                case field_8904 -> RarityType.EPIC;
                default -> RarityType.COMMON;
            };
        }
        return RarityType.COMMON;
    }
    private static RarityType detectCustomRarity(class_1799 stack) {
        class_2561 customName = stack.method_58694(class_9334.field_49631);
        if (customName != null) { RarityType r = parseComponentForRarity(customName); if (r != null) return r; }
        class_9290 lore = stack.method_58694(class_9334.field_49632);
        if (lore != null) { for (class_2561 line : lore.comp_2400()) { RarityType r = parseComponentForRarity(line); if (r != null) return r; } }
        return null;
    }
    private static RarityType parseComponentForRarity(class_2561 c) {
        String plain = c.getString().toLowerCase();
        if (contains(plain, "mythic")) return RarityType.MYTHIC;
        if (contains(plain, "legendary")) return RarityType.LEGENDARY;
        if (contains(plain, "epic")) return RarityType.EPIC;
        if (contains(plain, "rare")) return RarityType.RARE;
        if (contains(plain, "uncommon")) return RarityType.UNCOMMON;
        RarityType fromColor = detectRarityFromStyle(c.method_10866());
        if (fromColor != null) return fromColor;
        for (class_2561 s : c.method_10855()) { RarityType r = parseComponentForRarity(s); if (r != null) return r; }
        return null;
    }
    private static boolean contains(String text, String kw) {
        return text.contains(kw) || text.contains("["+kw+"]") || text.contains("("+kw+")");
    }
    private static RarityType detectRarityFromStyle(class_2583 style) {
        if (style == null || style.method_10973() == null) return null;
        int v = style.method_10973().method_27716();
        if (v == 0xFF55FF) return RarityType.MYTHIC;
        if (v == 0xFFAA00) return RarityType.LEGENDARY;
        if (v == 0xAA00AA) return RarityType.EPIC;
        if (v == 0x5555FF) return RarityType.RARE;
        if (v == 0x55FF55) return RarityType.UNCOMMON;
        return null;
    }
}