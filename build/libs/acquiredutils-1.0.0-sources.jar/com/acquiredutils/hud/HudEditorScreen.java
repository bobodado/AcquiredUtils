package com.acquiredutils.hud;

import com.acquiredutils.config.ConfigManager;
import com.acquiredutils.notification.Notification;
import com.acquiredutils.rarity.RarityType;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class HudEditorScreen extends class_437 {
    private static final int PW = 160, PH = 32;
    private static final class_2561 TITLE = class_2561.method_43470("AcquiredUtils HUD Editor");
    private boolean dragging = false;
    private int offX, offY, px, py;
    public HudEditorScreen() { super(TITLE); }
    @Override protected void method_25426() {
        super.method_25426();
        px = ConfigManager.get().notificationX >= 0 ? ConfigManager.get().notificationX : field_22789 - PW - 10;
        py = ConfigManager.get().notificationY >= 0 ? ConfigManager.get().notificationY : field_22790 / 2 - PH / 2;
    }
    @Override public void method_25394(class_332 g, int mx, int my, float pt) {
        g.method_25296(0, 0, field_22789, field_22790, 0xCC000000, 0xCC000000);
        int gc = 0x33FFFFFF;
        g.method_51738(0, field_22789, field_22790 / 4, gc); g.method_51738(0, field_22789, field_22790 / 2, gc); g.method_51738(0, field_22789, field_22790 * 3 / 4, gc);
        g.method_51742(field_22789 / 4, 0, field_22790, gc); g.method_51742(field_22789 / 2, 0, field_22790, gc); g.method_51742(field_22789 * 3 / 4, 0, field_22790, gc);
        g.method_25294(px, py, px + PW, py + PH, 0xCC141414);
        g.method_25294(px, py, px + 3, py + PH, 0xFFAA00AA);
        g.method_51433(class_310.method_1551().field_1772, "5x Diamond", px + 11, py + 12, 0xFFFFFFFF, false);
        if (over(mx, my)) {
            int o = 0xFFFFFFFF;
            g.method_51738(px - 1, px + PW + 1, py - 1, o); g.method_51738(px - 1, px + PW + 1, py + PH + 1, o);
            g.method_51742(px - 1, py - 1, py + PH + 1, o); g.method_51742(px + PW + 1, py - 1, py + PH + 1, o);
        }
        String ct = "X: " + px + " | Y: " + py;
        g.method_51433(class_310.method_1551().field_1772, ct, (field_22789 - class_310.method_1551().field_1772.method_1727(ct)) / 2, field_22790 - 30, 0xFFFFFFFF, true);
        String ht = "Drag to move | ESC to save";
        g.method_51433(class_310.method_1551().field_1772, ht, (field_22789 - class_310.method_1551().field_1772.method_1727(ht)) / 2, field_22790 - 18, 0xFFAAAAAA, true);
        super.method_25394(g, mx, my, pt);
    }
    private boolean over(int mx, int my) { return mx >= px && mx <= px + PW && my >= py && my <= py + PH; }
    @Override public boolean method_25402(class_11909 event, boolean bl) {
        if (event.method_74245() == 0 && over((int)event.comp_4798(), (int)event.comp_4799())) {
            dragging = true;
            offX = (int)event.comp_4798() - px;
            offY = (int)event.comp_4799() - py;
            return true;
        }
        return super.method_25402(event, bl);
    }
    @Override public boolean method_25403(class_11909 event, double dx, double dy) {
        if (dragging && event.method_74245() == 0) {
            px = Math.max(0, Math.min(field_22789 - PW, (int)event.comp_4798() - offX));
            py = Math.max(0, Math.min(field_22790 - PH, (int)event.comp_4799() - offY));
            return true;
        }
        return super.method_25403(event, dx, dy);
    }
    @Override public boolean method_25406(class_11909 event) {
        if (event.method_74245() == 0) dragging = false;
        return super.method_25406(event);
    }
    @Override public void method_25419() {
        ConfigManager.get().notificationX = px;
        ConfigManager.get().notificationY = py;
        ConfigManager.save();
        super.method_25419();
    }
    @Override public boolean method_25421() { return false; }
}