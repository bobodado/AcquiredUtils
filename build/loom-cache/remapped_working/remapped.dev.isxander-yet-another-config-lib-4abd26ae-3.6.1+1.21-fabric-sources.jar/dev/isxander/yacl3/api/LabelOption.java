package dev.isxander.yacl3.api;

import dev.isxander.yacl3.impl.LabelOptionImpl;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;
import net.minecraft.network.chat.Component;

/**
 * A label option is an easier way of creating a label with a {@link dev.isxander.yacl3.gui.controllers.LabelController}.
 * This option is immutable and cannot be disabled. Tooltips are supported through
 * {@link Component} styling.
 */
public interface LabelOption extends Option<Component> {
    @NotNull Component label();

    /**
     * Creates a new label option with the given label, skipping a builder for ease.
     */
    static LabelOption create(@NotNull Component label) {
        return new LabelOptionImpl(label);
    }

    static dev.isxander.yacl3.api.LabelOption.Builder createBuilder() {
        return new LabelOptionImpl.BuilderImpl();
    }

    interface Builder {
        dev.isxander.yacl3.api.LabelOption.Builder state(@NotNull StateManager<Component> stateManager);

        /**
         * Appends a line to the label
         */
        dev.isxander.yacl3.api.LabelOption.Builder line(@NotNull Component line);

        /**
         * Appends multiple lines to the label
         */
        dev.isxander.yacl3.api.LabelOption.Builder lines(@NotNull Collection<? extends Component> lines);

        LabelOption build();
    }
}
